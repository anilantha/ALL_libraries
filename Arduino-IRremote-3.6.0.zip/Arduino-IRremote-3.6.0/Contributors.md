## Contributors
These are the active contributors of this project that you may contact if there is anything you need help with or if you have suggestions.

- [ArminJo](https://github.com/ArminJo) Maintainer
- [z3t0](https://github.com/z3t0) the main contributor until version 2.4.0.
  * Email: zetoslab@gmail.com
- [shirriff](https://github.com/shirriff): An amazing person who worked to create this awesome library and provide unending support
- [Informatic](https://github.com/Informatic)
- [fmeschia](https://github.com/fmeschia)
- [PaulStoffregen](https://github.com/paulstroffregen)
- [crash7](https://github.com/crash7)
- [Neco777](https://github.com/neco777)
- [Lauszus](https://github.com/lauszus)
- [csBlueChip](https://github.com/csbluechip) contributed major and vital changes to the code base.
- [Sebazzz](https://github.com/sebazz)
- [lumbric](https://github.com/lumbric)
- [ElectricRCAircraftGuy](https://github.com/electricrcaircraftguy)
- [philipphenkel](https://github.com/philipphenkel)
- [MCUdude](https://github.com/MCUdude)
- [adamlhumphreys](https://github.com/adamlhumphreys) (code space improvements)
- [marcmerlin](https://github.com/marcmerlin) (ESP32 port)
- [MrBryonMiller](https://github.com/MrBryonMiller)
- [bengtmartensson](https://github.com/bengtmartensson) providing support
- [AnalysIR](https:/github.com/AnalysIR) providing support
- [eshicks4](https://github.com/eshicks4)
- [Jim-2249](https://github.com/Jim-2249)
- [pmalasp](https://github.com/pmalasp )


Note: Please let [ArminJo](https://github.com/ArminJo) know if you have been missed.
